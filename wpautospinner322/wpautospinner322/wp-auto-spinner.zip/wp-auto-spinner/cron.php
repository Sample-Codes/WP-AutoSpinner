<?php

//wp-load
require_once( '../../../wp-load.php' );


wp_auto_spinner_spin_function();